/**
 * 
 */

/**
 * @author usuario
 *
 */
public class GestionarListas {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lista lista[]=new Lista [5];
		
		lista[1]=new Lista(2);
		
		Leer.mensaje(lista[1].listar());
		Leer.mensaje("");
		lista[1].añadirnodo(5);
		lista[1].añadirnodo(6);
		lista[1].añadirnodo(7);
		lista[1].añadirnodo(1);
		lista[1].añadirnodo(5);
		lista[1].añadirnodo(7);
		lista[1].añadirnodo(6);
		
		
		Leer.mensaje(lista[1].listar());
		Leer.mensaje("");
		Integer valor=Leer.pedirEntero("Introduce que numeros desea borrar en la lista");
		if (!lista[1].buscadorNodo(valor)) {
			Leer.mensaje("No esta");
		} else {
				while (lista[1].buscadorNodo(valor)) {
					Leer.mensaje(lista[1].borrarnodo(valor));
				}
		}		
		Leer.mensaje("");
		Leer.mensaje(lista[1].listar());
	}

}
